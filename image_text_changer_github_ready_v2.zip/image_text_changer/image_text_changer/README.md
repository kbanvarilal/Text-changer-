# Image Text Changer

A Flutter app that detects text inside images (OCR), matches fonts approximately, allows editing text overlays and saves edited image to gallery.

## What's included
- `lib/main.dart` — app code (single-screen, OCR, on-device font matching, editable overlays, save to gallery)
- `pubspec.yaml` — dependencies and assets
- `assets/icon.svg` — app icon (T-shaped pen)
- README with build instructions

## Quick start
1. Install Flutter SDK and required tools (Android Studio/Xcode).
2. Run `flutter pub get`.
3. Connect a device and run `flutter run`.
4. Upload image → Scan & Match Fonts → Edit text → Save Image.

## Build
- Android APK: `flutter build apk --release`
- Android AAB: `flutter build appbundle --release`
- iOS IPA: (mac required) `flutter build ipa`

## Notes
- For exact font detection, provide an external font-detection API and set the URL/key in the code.
- iOS requires Apple Developer signing to build for App Store.
