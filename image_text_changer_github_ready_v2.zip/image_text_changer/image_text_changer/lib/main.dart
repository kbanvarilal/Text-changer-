// lib/main.dart
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:screenshot/screenshot.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:gallery_saver/gallery_saver.dart';
import 'package:google_fonts/google_fonts.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _mode = ThemeMode.system;

  void toggleTheme(bool isDark) {
    setState(() => _mode = isDark ? ThemeMode.dark : ThemeMode.light);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Image Text Changer',
      themeMode: _mode,
      theme: ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.teal,
        textTheme: GoogleFonts.robotoTextTheme(ThemeData.light().textTheme),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.teal,
        textTheme: GoogleFonts.robotoTextTheme(ThemeData.dark().textTheme),
      ),
      home: HomePage(onThemeChanged: toggleTheme, currentMode: _mode),
    );
  }
}

class DetectedTextField {
  Rect box; // in image pixel coordinates
  String text;
  TextEditingController controller;
  String matchedFontFamily;
  double fontSize;

  DetectedTextField({required this.box, required this.text, this.matchedFontFamily = 'Roboto', this.fontSize = 14.0})
      : controller = TextEditingController(text: text);
}

class HomePage extends StatefulWidget {
  final Function(bool) onThemeChanged;
  final ThemeMode currentMode;
  const HomePage({super.key, required this.onThemeChanged, required this.currentMode});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  File? _imageFile;
  ui.Image? _uiImage;
  final ImagePicker _picker = ImagePicker();
  final ScreenshotController _screenshotController = ScreenshotController();
  List<DetectedTextField> _fields = [];
  bool _isProcessing = false;

  final List<String> _candidateFamilies = [
    'Roboto',
    'Open Sans',
    'Lato',
    'Poppins',
    'Montserrat',
    'Source Sans Pro',
  ];

  // Optional external API configuration
  final String externalFontApiUrl = '';
  final String externalFontApiKey = '';

  Future<ui.Image> _loadUiImage(File file) async {
    final data = await file.readAsBytes();
    final codec = await ui.instantiateImageCodec(data);
    final frame = await codec.getNextFrame();
    return frame.image;
  }

  Future<void> _pickImage() async {
    final picked = await _picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    final file = File(picked.path);
    setState(() {
      _imageFile = file;
      _uiImage = null;
      _fields = [];
    });
    _uiImage = await _loadUiImage(file);
  }

  Future<void> _scanTextAndMatchFonts() async {
    if (_imageFile == null) return;
    setState(() => _isProcessing = true);

    final inputImage = InputImage.fromFile(_imageFile!);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);

    try {
      final RecognizedText recognized = await textRecognizer.processImage(inputImage);
      final List<DetectedTextField> results = [];

      for (final block in recognized.blocks) {
        for (final line in block.lines) {
          final rect = line.boundingBox;
          final box = Rect.fromLTWH(rect.left.toDouble(), rect.top.toDouble(), rect.width.toDouble(), rect.height.toDouble());
          final approxFontSize = box.height * 0.8;
          final dt = DetectedTextField(box: box, text: line.text, fontSize: approxFontSize);
          results.add(dt);
        }
      }

      for (final dt in results) {
        final matched = await _approximateFontMatch(dt.text, dt.fontSize);
        dt.matchedFontFamily = matched;

        if (externalFontApiUrl.isNotEmpty && externalFontApiKey.isNotEmpty) {
          try {
            final externalMatch = await _callExternalFontApi(dt);
            if (externalMatch.isNotEmpty) dt.matchedFontFamily = externalMatch;
          } catch (e) {
            debugPrint('External font API failed: $e');
          }
        }
      }

      setState(() => _fields = results);
    } catch (e) {
      debugPrint('OCR error: $e');
    } finally {
      textRecognizer.close();
      setState(() => _isProcessing = false);
    }
  }

  Future<String> _approximateFontMatch(String sample, double targetFontSize) async {
    if (sample.trim().isEmpty) return 'Roboto';
    double bestScore = double.infinity;
    String bestFamily = 'Roboto';

    for (final family in _candidateFamilies) {
      final tp = TextPainter(
        text: TextSpan(text: sample, style: _textStyleForFamily(family, targetFontSize)),
        textDirection: TextDirection.ltr,
        maxLines: 10,
      );
      tp.layout();
      final measured = tp.height;
      final score = (measured - targetFontSize).abs();
      if (score < bestScore) {
        bestScore = score;
        bestFamily = family;
      }
    }
    return bestFamily;
  }

  TextStyle _textStyleForFamily(String family, double size) {
    switch (family) {
      case 'Open Sans':
        return GoogleFonts.openSans(fontSize: size);
      case 'Lato':
        return GoogleFonts.lato(fontSize: size);
      case 'Poppins':
        return GoogleFonts.poppins(fontSize: size);
      case 'Montserrat':
        return GoogleFonts.montserrat(fontSize: size);
      case 'Source Sans Pro':
        return GoogleFonts.sourceSansPro(fontSize: size);
      default:
        return GoogleFonts.roboto(fontSize: size);
    }
  }

  Future<String> _callExternalFontApi(DetectedTextField dt) async {
    // Placeholder - implement according to your external API's spec if you have one
    return '';
  }

  Future<void> _saveEditedImage() async {
    if (_imageFile == null) return;
    await _requestPermissions();
    final bytes = await _screenshotController.capture(pixelRatio: 2.5);
    if (bytes == null) return;
    final dir = await getTemporaryDirectory();
    final file = await File('${dir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.png').create();
    await file.writeAsBytes(bytes);
    final success = await GallerySaver.saveImage(file.path, albumName: 'ImageTextChanger');
    if (success == true) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved to gallery (no watermark)')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Failed to save image')));
    }
  }

  Future<void> _requestPermissions() async {
    await [Permission.photos, Permission.storage].request();
  }

  Rect _convertRect(Rect srcBox, BoxConstraints constraints) {
    if (_uiImage == null) return srcBox;
    final double iw = _uiImage!.width.toDouble();
    final double ih = _uiImage!.height.toDouble();

    final double cw = constraints.maxWidth;
    final double ch = constraints.maxHeight;

    final double scale = _min(cw / iw, ch / ih);
    final double dw = iw * scale;
    final double dh = ih * scale;
    final double offsetX = (cw - dw) / 2.0;
    final double offsetY = (ch - dh) / 2.0;

    return Rect.fromLTWH(
      offsetX + srcBox.left * scale,
      offsetY + srcBox.top * scale,
      srcBox.width * scale,
      srcBox.height * scale,
    );
  }

  double _min(double a, double b) => a < b ? a : b;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Image Text Changer')),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(children: [
          Row(children: [
            ElevatedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.photo), label: const Text('Upload Image')),
            const SizedBox(width: 8),
            ElevatedButton.icon(onPressed: (_imageFile != null && !_isProcessing) ? _scanTextAndMatchFonts : null, icon: const Icon(Icons.search), label: const Text('Scan & Match Fonts')),
            const SizedBox(width: 8),
            ElevatedButton.icon(onPressed: (_imageFile != null) ? _saveEditedImage : null, icon: const Icon(Icons.save), label: const Text('Save Image')),
            const SizedBox(width: 8),
            Switch(
              value: Theme.of(context).brightness == Brightness.dark,
              onChanged: (v) => widget.onThemeChanged(v),
            ),
          ]),
          const SizedBox(height: 10),
          Expanded(
            child: Container(
              color: Colors.grey[200],
              child: _imageFile == null
                  ? const Center(child: Text('Upload an image to start'))
                  : LayoutBuilder(builder: (context, constraints) {
                      return Center(
                        child: SingleChildScrollView(
                          child: Screenshot(
                            controller: _screenshotController,
                            child: Container(
                              width: constraints.maxWidth,
                              height: constraints.maxHeight,
                              color: Colors.white,
                              child: Stack(children: [
                                Positioned.fill(
                                  child: FittedBox(fit: BoxFit.contain, child: Image.file(_imageFile!)),
                                ),
                                ..._fields.map((f) {
                                  final rect = _convertRect(f.box, constraints);
                                  final fontSize = f.fontSize.clamp(8.0, 128.0);
                                  final ts = _textStyleForFamily(f.matchedFontFamily, fontSize);
                                  return Positioned(
                                    left: rect.left,
                                    top: rect.top,
                                    width: rect.width,
                                    height: rect.height,
                                    child: GestureDetector(
                                      onTap: () {},
                                      child: Container(
                                        color: Colors.transparent,
                                        child: TextField(
                                          controller: f.controller,
                                          style: ts.copyWith(height: 1.0),
                                          maxLines: null,
                                          decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.zero),
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ]),
                            ),
                          ),
                        ),
                      );
                    }),
            ),
          ),
          if (_isProcessing) const LinearProgressIndicator(),
          const SizedBox(height: 8),
          const Text('Tip: Tap detected areas to edit. Font detection is approximate; use external API for higher accuracy.')
        ]),
      ),
    );
  }
}
